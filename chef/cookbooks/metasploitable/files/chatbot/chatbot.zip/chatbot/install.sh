#!/bin/sh

apt-get install npm

echo "Moving chatroom application"
cp -r /opt/chatbot/chat /var/www/html
chmod -R 777 /var/www/html/chat
mv /var/www/html/chat/log.html /var/www/

echo "Installing upstart script"
cp /opt/chatbot/chatbot.conf /etc/init/chatbot.conf

echo "ok, now run start.sh"
