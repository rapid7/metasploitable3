var express = require('express');
var cors = require('cors');
var app = express();
var exec = require('child_process').exec;

var corsOpts = {
  origin: '*',
};

app.use(cors(corsOpts));

app.get('/checkuser', function (req, res) {
  var user = req.query.user;
  if (user != "") {
    console.log("checking " + user);
    var cmd = "getent passwd " + user;
    console.log(cmd);
    exec(cmd, function(error, stdout, stderr) {
      if (stdout == "") {
        console.log("no data");
        res.send("Unknown user");
      } else {
        res.send(stdout);
      }
    });
  } else {
    console.log("no user given");
    res.send('No user given');
  }
})

app.listen(3000, function () {
  console.log('Server listening on localhost:3000');
})
